from django.apps import AppConfig


class SheetsConfig(AppConfig):
    name = "sheets"
