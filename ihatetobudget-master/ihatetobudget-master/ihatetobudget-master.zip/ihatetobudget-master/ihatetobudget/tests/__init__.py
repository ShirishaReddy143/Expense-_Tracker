import unittest

not_implemented = unittest.skip("Not implemented")
